// Popup controller — wires the form to the invite pipeline and renders the
// final result inline. Closing the popup cancels in-flight requests.

import { detectBmId } from './lib/bm-detect.js';
import {
  validateBmId,
  validateEmail,
  extractBmIdFromText,
} from './lib/validation.js';
import { sendInviteWithRetry } from './lib/invite.js';
import { randomString, openTab, inboxUrl, is282Mail, escapeHtml } from './lib/utils.js';
import { applyI18n, t } from './lib/i18n.js';
import { initAcceptTab } from './lib/accept-ui.js';

// Note: only the FB session token is cached (in chrome.storage.session, see
// lib/token.js). BM ID, email, and role are NOT persisted — every popup open
// starts fresh. Auto-detect handles the BM ID; the user types the email each
// time.

const els = {};
const state = {
  sending: false,
  bmIdAutoMessage: '',
};

const $ = (id) => document.getElementById(id);

// =====================================================================
// Init
// =====================================================================

function init() {
  applyI18n();
  bindElements();
  bindEvents();
  const activateAcceptTab = initTabs();
  // Auto-detect first so the invite tab is ready; the accept tab resumes any
  // unfinished job and, if it does, switches to itself via activateAcceptTab.
  autoDetectBmId().catch((e) => console.error('[FastInviteBM] auto-detect failed', e));
  initAcceptTab(activateAcceptTab);
}

// WAI-ARIA tabs with roving tabindex. Returns a function that activates the
// Accept tab (used by the accept controller when it auto-resumes a job).
function initTabs() {
  const tabs = [...document.querySelectorAll('.tab')];
  const panels = tabs.map((tab) => document.getElementById(tab.getAttribute('aria-controls')));

  function activate(index, { focus = false } = {}) {
    tabs.forEach((tab, i) => {
      const selected = i === index;
      tab.setAttribute('aria-selected', selected ? 'true' : 'false');
      tab.tabIndex = selected ? 0 : -1;
      panels[i].hidden = !selected;
    });
    if (focus) tabs[index].focus();
  }

  tabs.forEach((tab, i) => {
    tab.addEventListener('click', () => activate(i));
    tab.addEventListener('keydown', (e) => {
      let next = null;
      if (e.key === 'ArrowRight') next = (i + 1) % tabs.length;
      else if (e.key === 'ArrowLeft') next = (i - 1 + tabs.length) % tabs.length;
      else if (e.key === 'Home') next = 0;
      else if (e.key === 'End') next = tabs.length - 1;
      if (next !== null) {
        e.preventDefault();
        activate(next, { focus: true });
      }
    });
  });

  const acceptIndex = tabs.findIndex((tab) => tab.id === 'tab-accept');
  return () => activate(acceptIndex);
}

function bindElements() {
  els.form = $('invite-form');
  els.bmId = $('bmId');
  els.bmIdHelp = $('bmId-help');
  els.email = $('email');
  els.emailHelp = $('email-help');
  els.randomBtn = $('randomBtn');
  els.openInboxBtn = $('openInboxBtn');
  els.role = $('role');
  els.sendBtn = $('sendBtn');
  els.sendBtnLabel = els.sendBtn.querySelector('.btn-label');
  els.sendBtnIcon = els.sendBtn.querySelector('.btn-icon');
  els.resultPanel = $('result-panel');
}

function bindEvents() {
  els.bmId.addEventListener('input', () => onFieldInput('bmId'));
  els.bmId.addEventListener('blur', () => onFieldBlur('bmId'));
  els.bmId.addEventListener('paste', onBmIdPaste);
  els.email.addEventListener('input', () => onFieldInput('email'));
  els.email.addEventListener('blur', () => onFieldBlur('email'));
  els.randomBtn.addEventListener('click', onRandom);
  els.openInboxBtn.addEventListener('click', onOpenInbox);
  els.form.addEventListener('submit', onSubmit);
  updateInboxLinkVisibility();
}

function updateInboxLinkVisibility() {
  const show = is282Mail(els.email.value);
  els.openInboxBtn.hidden = !show;
}

async function autoDetectBmId() {
  let detected = null;
  try {
    detected = await detectBmId();
  } catch {
    /* ignore — fallback to manual */
  }

  // Only auto-fill if user hasn't started interacting with the BM ID field.
  // (autoDetectBmId can race the user — they may begin typing during the
  // detect call. We don't want to overwrite their input.)
  const userTouchedField =
    document.activeElement === els.bmId || els.bmId.dataset.userTouched === '1';

  // Only steal focus if user isn't already interacting with another form
  // element (avoids yanking focus away from role/email if the detect call
  // resolves slowly).
  const safeToMoveFocus =
    document.activeElement === document.body ||
    document.activeElement == null;

  if (detected && detected !== els.bmId.value && !userTouchedField) {
    els.bmId.value = detected;
    state.bmIdAutoMessage = t('bmIdAutoDetected');
    setHelp('bmId', state.bmIdAutoMessage, 'success');
    validateField('bmId', { keepStickyHelp: true });
    if (safeToMoveFocus) els.email.focus();
  } else if (!els.bmId.value && safeToMoveFocus) {
    els.bmId.focus();
  } else if (!userTouchedField && safeToMoveFocus) {
    els.email.focus();
  }
  updateSendButton();
}

// =====================================================================
// Validation
// =====================================================================

function setHelp(field, msg, kind = '') {
  const el = field === 'bmId' ? els.bmIdHelp : els.emailHelp;
  el.textContent = msg || '';
  el.className = 'help' + (kind ? ` ${kind}` : '');
}

function validateField(field, { quiet = false, keepStickyHelp = false } = {}) {
  const input = field === 'bmId' ? els.bmId : els.email;
  const v = (input.value || '').trim();
  const r = field === 'bmId' ? validateBmId(v) : validateEmail(v);

  if (!v) {
    input.removeAttribute('aria-invalid');
    if (!quiet) setHelp(field, '');
    return false;
  }
  if (r.valid) {
    input.setAttribute('aria-invalid', 'false');
    if (!quiet) {
      if (field === 'bmId' && keepStickyHelp && state.bmIdAutoMessage) {
        setHelp('bmId', state.bmIdAutoMessage, 'success');
      } else {
        setHelp(field, '');
      }
    }
    return true;
  }
  input.setAttribute('aria-invalid', 'true');
  if (!quiet) setHelp(field, t(r.error), 'error');
  return false;
}

function isFormValid() {
  return (
    validateBmId(els.bmId.value.trim()).valid &&
    validateEmail(els.email.value.trim()).valid
  );
}

function updateSendButton() {
  const valid = isFormValid();
  els.sendBtn.disabled = !valid || state.sending;
}

// =====================================================================
// Field events
// =====================================================================

function onFieldInput(field) {
  const input = field === 'bmId' ? els.bmId : els.email;
  if (input.getAttribute('aria-invalid') === 'true') {
    validateField(field);
  }
  if (field === 'bmId') {
    state.bmIdAutoMessage = '';
    els.bmId.dataset.userTouched = '1';
  }
  if (field === 'email') {
    updateInboxLinkVisibility();
  }
  updateSendButton();
}

function onFieldBlur(field) {
  validateField(field);
}

function onBmIdPaste(e) {
  const txt = (e.clipboardData?.getData('text') || '').trim();
  const id = extractBmIdFromText(txt);
  if (id && id !== txt) {
    e.preventDefault();
    els.bmId.value = id;
    els.bmId.dataset.userTouched = '1';
    state.bmIdAutoMessage = t('bmIdExtractedFromUrl');
    setHelp('bmId', state.bmIdAutoMessage, 'success');
    validateField('bmId', { keepStickyHelp: true });
    updateSendButton();
  }
}

function onRandom() {
  const bmId = (els.bmId.value || '').trim();
  const tail = validateBmId(bmId).valid ? bmId : '';
  const email = `m${randomString(3)}${tail}@282mail.com`;
  els.email.value = email;
  els.email.setAttribute('aria-invalid', 'false');
  setHelp('email', '');
  els.email.focus();
  els.email.select();
  updateInboxLinkVisibility();
  updateSendButton();
}

function onOpenInbox(e) {
  e.preventDefault();
  const email = (els.email.value || '').trim();
  if (!validateEmail(email).valid) {
    setHelp('email', t('errInvalidEmail'), 'error');
    els.email.setAttribute('aria-invalid', 'true');
    els.email.focus();
    return;
  }
  if (!is282Mail(email)) return; // link should be hidden in this state
  openTab(inboxUrl(email));
}

// =====================================================================
// Send button visual state
// =====================================================================

function setSendButtonSending(sending) {
  if (sending) {
    els.sendBtnIcon.innerHTML = '<span class="spinner" aria-hidden="true"></span>';
    els.sendBtnLabel.textContent = t('btnSending');
    els.sendBtn.setAttribute('aria-busy', 'true');
  } else {
    els.sendBtnIcon.innerHTML = '';
    els.sendBtnLabel.textContent = t('btnSend');
    els.sendBtn.removeAttribute('aria-busy');
  }
}

// =====================================================================
// Result rendering
// =====================================================================

function renderResult(result, sent = {}) {
  els.resultPanel.hidden = false;

  // Use the email/BM ID we actually sent (captured before await), not the
  // current field values — defensive in case the form was somehow modified
  // between the API call returning and this render.
  const sentEmail = sent.email ?? els.email.value.trim();
  const sentBmId = sent.bmId ?? els.bmId.value.trim();

  if (result.success) {
    const showInbox = is282Mail(sentEmail);
    els.resultPanel.className = 'result-panel success';
    els.resultPanel.innerHTML = `
      <h3 class="result-title">
        <span class="result-icon" aria-hidden="true">✓</span>
        ${escapeHtml(t('resultSuccess'))}
      </h3>
      <dl class="result-meta">
        <dt>${escapeHtml(t('labelEmail'))}</dt>
        <dd>${escapeHtml(sentEmail)}</dd>
        <dt>${escapeHtml(t('labelBmIdShort'))}</dt>
        <dd>${escapeHtml(sentBmId)}</dd>
      </dl>
      <div class="result-actions">
        ${showInbox ? `<button type="button" class="btn-ghost" id="resultOpenInbox">${escapeHtml(t('btnOpenInbox'))} ↗</button>` : ''}
        <button type="button" class="btn-ghost" id="resultSendAnother">${escapeHtml(t('btnSendAnother'))}</button>
      </div>
    `;
    if (showInbox) {
      $('resultOpenInbox')?.addEventListener('click', () =>
        openTab(inboxUrl(sentEmail))
      );
    }
    $('resultSendAnother')?.addEventListener('click', resetForNext);
    // Move focus to the most useful next action so keyboard users don't have
    // to tab past the disabled-then-re-enabled Send button.
    ($('resultOpenInbox') || $('resultSendAnother'))?.focus();
    return;
  }

  // Failure: show user-friendly error with optional technical details.
  els.resultPanel.className = 'result-panel error';
  const hasDetails = result.primaryError || result.fallbackError;
  const detailHtml = hasDetails
    ? `<details class="collapsible"><summary>${escapeHtml(t('resultShowDetails'))}</summary><pre>${escapeHtml(
        [result.primaryError, result.fallbackError].filter(Boolean).join('\n\n')
      )}</pre></details>`
    : '';
  els.resultPanel.innerHTML = `
    <h3 class="result-title">
      <span class="result-icon" aria-hidden="true">✗</span>
      ${escapeHtml(t('resultFail'))}
    </h3>
    <p class="result-message">${escapeHtml(result.error || t('resultFailGeneric'))}</p>
    ${detailHtml}
    <div class="result-actions">
      <button type="button" class="btn-ghost" id="resultRetry">${escapeHtml(t('btnTryAgain'))}</button>
    </div>
  `;
  $('resultRetry')?.addEventListener('click', () => {
    els.resultPanel.hidden = true;
    els.sendBtn.focus();
  });
  $('resultRetry')?.focus();
}

function resetForNext() {
  els.email.value = '';
  els.email.removeAttribute('aria-invalid');
  setHelp('email', '');
  els.resultPanel.hidden = true;
  updateInboxLinkVisibility();
  els.email.focus();
  updateSendButton();
}

// =====================================================================
// Submit
// =====================================================================

function setFormDisabled(disabled) {
  for (const el of els.form.elements) el.disabled = disabled;
}

async function onSubmit(e) {
  e.preventDefault();
  if (state.sending) return;
  if (!isFormValid()) {
    validateField('bmId');
    validateField('email');
    return;
  }

  state.sending = true;
  els.resultPanel.hidden = true;

  const bmId = els.bmId.value.trim();
  const email = els.email.value.trim();
  const role = els.role.value;

  setFormDisabled(true);
  setSendButtonSending(true);

  let result;
  try {
    result = await sendInviteWithRetry({ bmId, email, role });
  } catch (err) {
    result = { success: false, error: err?.message || String(err) };
  }

  state.sending = false;
  setFormDisabled(false);
  setSendButtonSending(false);
  renderResult(result, { bmId, email });
  updateSendButton();
}

init();
